import PDFOrganizeTool from "@/components/PDFOrganizeTool";
export default function Page() {
  return (
    <main className="max-w-3xl mx-auto px-4 py-10">
      <PDFOrganizeTool />
    </main>
  );
}
